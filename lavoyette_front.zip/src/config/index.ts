export const site_api = "https://www.wp.lavoyette.fr/wp-json/wp/v2/"
